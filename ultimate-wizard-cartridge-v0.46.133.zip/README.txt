ULTIMATE WIZARD 0.46.133 — CAR 1 MB

Atari XL/XE: 64 KB RAM. BASIC off. No RAM expansion required.
Copy the .car file to AVGCart / SUBCart and launch it from the cartridge menu.
For A8PicoCart, use firmware with AtariMax 1 MB / CAR type42 enabled.
The maintained ascrnet implementation targets Winbond 16 MB RP2040 modules:
https://github.com/ascrnet/A8PicoCart/blob/main/TYPE42.md
The standard A8PicoCart firmware does not support a 1 MB CAR.

Hold SELECT during startup for the level selector.
Normal startup: EA logo, Rasta illustration, instructions, animated title, menu.
FIRE or START skips the illustration.
During level and score/menu loading, a color wizard walks back and forth in
the lower-right corner. It disappears when the next screen is ready.

The game needs no D1 disk. Creator saves and loads user maps on D2.
Use the included blank user-map ATR as writable D2, through your cartridge's
disk facility or a separate Atari SIO device. The CAR itself is read-only.

Validated in Atari800 and unmodified Altirra 4.10/Wine on 64 KB.
Native Atari XL OS rev 2 and AltirraOS are covered. The cartridge interlock
is refreshed before VBI. The invisible wizard's head, hands and feet are
visible from casting.
Physical AVGCart/SUBCart/A8PicoCart testing has not been performed here.
Full source and validation: https://github.com/banshee997-prog/ultimate-wizard
